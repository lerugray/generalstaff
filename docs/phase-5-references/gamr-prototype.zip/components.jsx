// Shared primitives: Boxart tile, VibeSliders, VibeTags, VibeProse, VibeRadar, PlatformChip

const { useEffect, useMemo, useRef, useState } = React;

// --- Boxart: striped SVG placeholder with mono text overlay ---
function Boxart({ code, size = "md" }) {
  const g = window.GAMES[code];
  if (!g) return null;
  const w = size === "lg" ? 220 : size === "sm" ? 80 : 150;
  const h = Math.round(w * 1.35);
  const bg = `oklch(0.78 0.08 ${g.hue})`;
  const ink = `oklch(0.28 0.06 ${g.hue})`;
  const stripe = `oklch(0.70 0.10 ${g.hue})`;

  let pattern;
  if (g.stripe === "diag") {
    pattern = (
      <pattern id={`p-${code}`} patternUnits="userSpaceOnUse" width="10" height="10" patternTransform="rotate(35)">
        <rect width="10" height="10" fill={bg}/>
        <rect width="4" height="10" fill={stripe}/>
      </pattern>
    );
  } else if (g.stripe === "horiz") {
    pattern = (
      <pattern id={`p-${code}`} patternUnits="userSpaceOnUse" width="12" height="12">
        <rect width="12" height="12" fill={bg}/>
        <rect width="12" height="4" fill={stripe}/>
      </pattern>
    );
  } else {
    pattern = (
      <pattern id={`p-${code}`} patternUnits="userSpaceOnUse" width="12" height="12">
        <rect width="12" height="12" fill={bg}/>
        <rect width="4" height="12" fill={stripe}/>
      </pattern>
    );
  }

  return (
    <div className="boxart" style={{ width: w, height: h }}>
      <svg viewBox={`0 0 ${w} ${h}`} width={w} height={h} style={{ display: "block" }}>
        <defs>{pattern}</defs>
        <rect width={w} height={h} fill={`url(#p-${code})`}/>
        <rect x="6" y="6" width={w-12} height={h-12} fill="none" stroke={ink} strokeWidth="1.2" strokeDasharray="3 3" opacity="0.5"/>
        {/* Title block */}
        <rect x="10" y={h - 58} width={w-20} height="44" fill="oklch(0.97 0.02 80)" stroke={ink} strokeWidth="1"/>
        <text x={w/2} y={h-40} textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize={size === "lg" ? 13 : 10} fontWeight="700" fill={ink} letterSpacing="0.04em">
          {g.title.length > 14 ? g.title.slice(0,14) : g.title}
        </text>
        <text x={w/2} y={h-24} textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize={size === "lg" ? 9 : 7} fill={ink} opacity="0.7" letterSpacing="0.1em">
          {g.genre}
        </text>
        {/* Corner mark */}
        <circle cx="16" cy="16" r="6" fill="oklch(0.97 0.02 80)" stroke={ink} strokeWidth="1"/>
        <text x="16" y="19" textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="7" fontWeight="700" fill={ink}>{code.slice(0,3)}</text>
      </svg>
    </div>
  );
}

// --- Platform chip ---
function PlatformChip({ name }) {
  return <span className="platform-chip">{name}</span>;
}

// --- VIBE VARIATION 1: Dual sliders ---
function VibeSliders({ vibe }) {
  const rows = [
    { l: "CHILL", r: "TRYHARD", val: 100 - vibe.chill + vibe.tryhard, // blend
      // Use direct tryhard score
      value: vibe.tryhard },
    { l: "QUIET", r: "CHATTY", value: vibe.chatty },
    { l: "SOLO-OK", r: "MENTOR", value: vibe.mentor },
  ];
  return (
    <div className="vibe-sliders">
      {rows.map((row, i) => (
        <div key={i} className="vibe-row">
          <span className="vibe-label vibe-label-l">{row.l}</span>
          <div className="vibe-track">
            <div className="vibe-ticks">
              {[0,1,2,3,4,5,6,7,8,9,10].map(t => <span key={t} className="vibe-tick"/>)}
            </div>
            <div className="vibe-dot" style={{ left: `calc(${row.value}% - 7px)` }}/>
          </div>
          <span className="vibe-label vibe-label-r">{row.r}</span>
        </div>
      ))}
    </div>
  );
}

// --- VIBE VARIATION 2: Stamped tags ---
function VibeTags({ vibe, tags }) {
  return (
    <div className="vibe-tags">
      {tags.map((t, i) => (
        <span key={i} className="vibe-tag" style={{ transform: `rotate(${((i*37)%7 - 3)*0.6}deg)` }}>
          {t}
        </span>
      ))}
    </div>
  );
}

// --- VIBE VARIATION 3: Prose (handwritten-feel italic) ---
function VibeProse({ prose }) {
  return (
    <div className="vibe-prose">
      <div className="prose-row">
        <span className="prose-q">Q. Why do you play?</span>
        <span className="prose-a">{prose.play}</span>
      </div>
      <div className="prose-row">
        <span className="prose-q">Q. How do you talk in voice?</span>
        <span className="prose-a">{prose.talk}</span>
      </div>
    </div>
  );
}

// --- VIBE VARIATION 4: Radar chart ---
function VibeRadar({ vibe }) {
  const axes = [
    { k: "CHILL",   v: vibe.chill },
    { k: "CHATTY",  v: vibe.chatty },
    { k: "MENTOR",  v: vibe.mentor },
    { k: "TRYHARD", v: vibe.tryhard },
    { k: "QUIET",   v: vibe.quiet },
  ];
  const n = axes.length;
  const cx = 90, cy = 90, R = 68;
  const pt = (i, r) => {
    const a = -Math.PI/2 + (i / n) * Math.PI * 2;
    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
  };
  const poly = axes.map((ax, i) => pt(i, (ax.v/100) * R).join(",")).join(" ");
  return (
    <div className="vibe-radar">
      <svg viewBox="0 0 180 180" width="180" height="180">
        {[0.25, 0.5, 0.75, 1].map((f, k) => (
          <polygon key={k}
            points={axes.map((_, i) => pt(i, R*f).join(",")).join(" ")}
            fill="none" stroke="currentColor" strokeWidth="0.6" opacity={0.25}/>
        ))}
        {axes.map((_, i) => {
          const [x, y] = pt(i, R);
          return <line key={i} x1={cx} y1={cy} x2={x} y2={y} stroke="currentColor" strokeWidth="0.6" opacity="0.25"/>;
        })}
        <polygon points={poly} fill="oklch(0.55 0.18 25 / 0.25)" stroke="oklch(0.55 0.18 25)" strokeWidth="1.4"/>
        {axes.map((ax, i) => {
          const [x, y] = pt(i, R + 14);
          return (
            <text key={ax.k} x={x} y={y} textAnchor="middle" dominantBaseline="middle"
              fontFamily="JetBrains Mono, monospace" fontSize="8" fontWeight="700" fill="currentColor" letterSpacing="0.08em">
              {ax.k}
            </text>
          );
        })}
      </svg>
    </div>
  );
}

Object.assign(window, { Boxart, PlatformChip, VibeSliders, VibeTags, VibeProse, VibeRadar });
