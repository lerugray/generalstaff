// App shell: prev/next, keyboard, swipe (drag), pass/connect/save/invite/message, undo, filter, tweaks, mobile.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "vibeMode": "sliders",
  "accent": "#B13A2B",
  "density": "ruled",
  "showChrome": true,
  "cardRotation": 1.2,
  "boxartSprite": "striped"
}/*EDITMODE-END*/;

function useTweaks() {
  const [t, setT] = React.useState(TWEAK_DEFAULTS);
  React.useEffect(() => {
    const onMsg = (e) => {
      if (!e.data || typeof e.data !== "object") return;
      if (e.data.type === "__apply_edits" && e.data.edits) {
        setT(prev => ({ ...prev, ...e.data.edits }));
      }
    };
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);
  const update = (patch) => {
    setT(prev => ({ ...prev, ...patch }));
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: patch }, "*");
  };
  return [t, update];
}

function App() {
  const profiles = window.PROFILES;
  const [tweaks, setTweaks] = useTweaks();
  const [idx, setIdx] = React.useState(() => {
    const saved = parseInt(localStorage.getItem("gamr_idx") || "0", 10);
    return Number.isFinite(saved) && saved >= 0 && saved < profiles.length ? saved : 0;
  });
  const [flipped, setFlipped] = React.useState(false);
  const [history, setHistory] = React.useState([]); // {action, idx}
  const [toast, setToast] = React.useState(null);
  const [drag, setDrag] = React.useState({ dx: 0, dragging: false });
  const [exitDir, setExitDir] = React.useState(null); // "left" | "right" | "up" | "down"
  const [filters, setFilters] = React.useState({ platform: "ANY", game: "ANY", window: "ANY" });
  const [editMode, setEditMode] = React.useState(false);
  const stageRef = React.useRef(null);
  const fitRef = React.useRef(null);

  // Scale-to-fit: compute scale so 820x560 card fits the stage.
  // Scale AND set width/height so the layout box matches the visual size.
  React.useEffect(() => {
    if (!stageRef.current || !fitRef.current) return;
    const stage = stageRef.current;
    const fit = fitRef.current;
    const CARD_W = 820, CARD_H = 640, PAD_X = 40, PAD_Y = 24;
    const update = () => {
      const w = stage.clientWidth, h = stage.clientHeight;
      if (!w || !h) return;
      const s = Math.min(1, (w - PAD_X*2) / CARD_W, (h - PAD_Y*2) / CARD_H);
      const clamped = Math.max(0.2, s);
      fit.style.transform = `scale(${clamped})`;
      fit.style.transformOrigin = "top left";
      // Shrink the layout box to match the scaled visual size
      fit.style.width = (CARD_W * clamped) + "px";
      fit.style.height = (CARD_H * clamped) + "px";
      fit.style.setProperty("--fit-scale", String(clamped));
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(stage);
    window.addEventListener("resize", update);
    return () => { ro.disconnect(); window.removeEventListener("resize", update); };
  }, []);

  // Persist index
  React.useEffect(() => { localStorage.setItem("gamr_idx", String(idx)); }, [idx]);

  // Filter
  const filtered = React.useMemo(() => {
    return profiles.filter(p => {
      if (filters.platform !== "ANY" && !p.platforms.includes(filters.platform)) return false;
      if (filters.game !== "ANY" && !p.games.includes(filters.game) && !p.wants.includes(filters.game)) return false;
      if (filters.window === "EVE" && !/2[0-3]:|1[89]:/.test(p.window)) return false;
      if (filters.window === "MORN" && !/0[6-9]:|1[0-1]:/.test(p.window)) return false;
      if (filters.window === "LATE" && !/2[2-3]:|0[0-2]:/.test(p.window)) return false;
      return true;
    });
  }, [filters, profiles]);

  // Keep idx in bounds of filtered
  React.useEffect(() => {
    if (idx >= filtered.length) setIdx(Math.max(0, filtered.length - 1));
  }, [filtered.length]);

  const current = filtered[idx];

  const showToast = (text, kind = "info") => {
    setToast({ text, kind, key: Date.now() });
    setTimeout(() => setToast(t => (t && t.text === text ? null : t)), 1800);
  };

  const advance = (action, dir = "right") => {
    if (!current) return;
    setExitDir(dir);
    setHistory(h => [...h, { action, profileId: current.id, idx }]);
    setTimeout(() => {
      setIdx(i => Math.min(i + 1, filtered.length - 1));
      setFlipped(false);
      setExitDir(null);
      setDrag({ dx: 0, dragging: false });
    }, 280);
  };

  const onAction = (a) => {
    if (!current) return;
    if (a === "pass")     { showToast("PASSED",   "pass");    advance("pass", "left"); }
    if (a === "connect")  { showToast("CONNECT REQUEST SENT", "connect"); advance("connect", "right"); }
    if (a === "save")     { showToast("SAVED FOR LATER", "save"); advance("save", "up"); }
    if (a === "message")  { showToast("MESSAGE COMPOSER…", "msg"); }
    if (a === "invite")   { showToast(`INVITED TO ${window.GAMES[current.wants[0]].title}`, "invite"); }
    if (a === "report")   { showToast("REPORT FILED", "report"); }
  };

  const onUndo = () => {
    setHistory(h => {
      if (!h.length) return h;
      const last = h[h.length - 1];
      setIdx(last.idx);
      showToast(`UNDONE: ${last.action.toUpperCase()}`);
      return h.slice(0, -1);
    });
  };

  // Keyboard
  React.useEffect(() => {
    const onKey = (e) => {
      if (e.target && ["INPUT","TEXTAREA","SELECT"].includes(e.target.tagName)) return;
      if (e.key === "ArrowRight") { e.preventDefault(); setIdx(i => Math.min(i+1, filtered.length-1)); setFlipped(false); }
      else if (e.key === "ArrowLeft")  { e.preventDefault(); setIdx(i => Math.max(i-1, 0)); setFlipped(false); }
      else if (e.key === " " || e.key === "Enter") { e.preventDefault(); setFlipped(f => !f); }
      else if (e.key === "c" || e.key === "C") onAction("connect");
      else if (e.key === "x" || e.key === "X") onAction("pass");
      else if (e.key === "s" || e.key === "S") onAction("save");
      else if (e.key === "m" || e.key === "M") onAction("message");
      else if (e.key === "u" || e.key === "U") onUndo();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [filtered.length, current, history]);

  // Drag (mouse + touch)
  const dragRef = React.useRef({ startX: 0, startY: 0, startT: 0 });
  const onPointerDown = (e) => {
    if (flipped) return;
    const p = e.touches ? e.touches[0] : e;
    dragRef.current = { startX: p.clientX, startY: p.clientY, startT: Date.now() };
    setDrag({ dx: 0, dragging: true });
  };
  const onPointerMove = (e) => {
    if (!drag.dragging) return;
    const p = e.touches ? e.touches[0] : e;
    const dx = p.clientX - dragRef.current.startX;
    setDrag({ dx, dragging: true });
  };
  const onPointerUp = () => {
    if (!drag.dragging) return;
    const dx = drag.dx;
    if (dx > 120) onAction("connect");
    else if (dx < -120) onAction("pass");
    else setDrag({ dx: 0, dragging: false });
  };

  // Edit mode protocol
  React.useEffect(() => {
    const onMsg = (e) => {
      if (!e.data) return;
      if (e.data.type === "__activate_edit_mode")   setEditMode(true);
      if (e.data.type === "__deactivate_edit_mode") setEditMode(false);
    };
    window.addEventListener("message", onMsg);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);

  // Accent via CSS var
  React.useEffect(() => {
    document.documentElement.style.setProperty("--accent", tweaks.accent);
  }, [tweaks.accent]);

  if (!current) {
    return (
      <div className="empty-state">
        <div className="empty-inner">
          <div className="empty-stamp">NO MATCHES</div>
          <p>No one fits your filter. Loosen it.</p>
          <button className="btn" onClick={() => setFilters({ platform: "ANY", game: "ANY", window: "ANY" })}>RESET FILTERS</button>
        </div>
      </div>
    );
  }

  const rotateBase = tweaks.cardRotation || 0;
  const dx = drag.dx;
  const cardTransform = exitDir === "left"  ? `translateX(-140%) rotate(-18deg)` :
                        exitDir === "right" ? `translateX(140%)  rotate(18deg)` :
                        exitDir === "up"    ? `translateY(-140%) rotate(-4deg)` :
                        `translateX(${dx}px) rotate(${rotateBase + dx*0.05}deg)`;

  const intentLabel =
    dx > 60 ? "CONNECT →" :
    dx < -60 ? "← PASS" : null;

  return (
    <div className="app">
      <TopBar filters={filters} setFilters={setFilters} onUndo={onUndo} canUndo={history.length > 0} idx={idx} total={filtered.length}/>

      <div ref={stageRef} className="stage" onMouseMove={onPointerMove} onMouseUp={onPointerUp} onMouseLeave={onPointerUp} onTouchMove={onPointerMove} onTouchEnd={onPointerUp}>
        {/* Ghost cards peeking behind */}
        {filtered[idx+1] && <div className="ghost-card ghost-card-back"><GhostCard p={filtered[idx+1]}/></div>}
        {filtered[idx+2] && <div className="ghost-card ghost-card-way-back"><GhostCard p={filtered[idx+2]}/></div>}

        <div ref={fitRef} className="card-fit">
        <div
          className={`card-stage ${drag.dragging ? "dragging" : ""} ${exitDir ? "exiting" : ""}`}
          style={{ transform: cardTransform }}
          onMouseDown={onPointerDown}
          onTouchStart={onPointerDown}
        >
          <ProfileCard
            profile={current}
            vibeMode={tweaks.vibeMode}
            density={tweaks.density}
            flipped={flipped}
            onFlip={() => setFlipped(f => !f)}
            accent={tweaks.accent}
          />
          {intentLabel && (
            <div className={`intent-stamp ${dx > 0 ? "intent-connect" : "intent-pass"}`}>
              {intentLabel}
            </div>
          )}
        </div>
        </div>

        {/* Nav affordances */}
        <button className="nav-btn nav-prev" onClick={() => { setIdx(i => Math.max(0, i-1)); setFlipped(false); }} disabled={idx === 0}>
          <span className="nav-arrow">←</span>
          <span className="nav-key">[←]</span>
        </button>
        <button className="nav-btn nav-next" onClick={() => { setIdx(i => Math.min(filtered.length-1, i+1)); setFlipped(false); }} disabled={idx >= filtered.length-1}>
          <span className="nav-arrow">→</span>
          <span className="nav-key">[→]</span>
        </button>
      </div>

      <ActionBar onAction={onAction} wantsGame={current.wants[0]}/>

      <HelpStrip/>

      {toast && <Toast text={toast.text} kind={toast.kind} key={toast.key}/>}

      {editMode && <TweaksPanel tweaks={tweaks} setTweaks={setTweaks}/>}
    </div>
  );
}

function GhostCard({ p }) {
  return (
    <div className="ghost-inner">
      <div className="ghost-id">GAMR / NO. {p.id}</div>
      <div className="ghost-name">{p.name}</div>
    </div>
  );
}

function TopBar({ filters, setFilters, onUndo, canUndo, idx, total }) {
  return (
    <header className="topbar">
      <GamrLogo/>
      <div className="filter-row">
        <span className="filter-label">FILTER /</span>
        <select value={filters.platform} onChange={e => setFilters(f => ({...f, platform: e.target.value}))}>
          <option value="ANY">ANY PLATFORM</option>
          <option value="PC">PC</option>
          <option value="PLAYSTATION">PLAYSTATION</option>
          <option value="SWITCH">SWITCH</option>
          <option value="MOBILE">MOBILE</option>
          <option value="TABLETOP">TABLETOP</option>
        </select>
        <select value={filters.game} onChange={e => setFilters(f => ({...f, game: e.target.value}))}>
          <option value="ANY">ANY GAME</option>
          {Object.entries(window.GAMES).map(([k,v]) => <option key={k} value={k}>{v.title}</option>)}
        </select>
        <select value={filters.window} onChange={e => setFilters(f => ({...f, window: e.target.value}))}>
          <option value="ANY">ANY WINDOW</option>
          <option value="MORN">MORNINGS</option>
          <option value="EVE">EVENINGS</option>
          <option value="LATE">LATE NIGHT</option>
        </select>
      </div>
      <div className="top-right">
        <div className="counter">{String(idx+1).padStart(3,"0")} / {String(total).padStart(3,"0")}</div>
        <button className="undo-btn" onClick={onUndo} disabled={!canUndo}>⟲ UNDO [U]</button>
      </div>
    </header>
  );
}

function ActionBar({ onAction, wantsGame }) {
  return (
    <div className="action-bar">
      <button className="act act-pass"    onClick={() => onAction("pass")}>
        <span className="act-glyph">✕</span>
        <span className="act-lbl">PASS</span>
        <span className="act-key">[X]</span>
      </button>
      <button className="act act-save"    onClick={() => onAction("save")}>
        <span className="act-glyph">☐</span>
        <span className="act-lbl">SAVE</span>
        <span className="act-key">[S]</span>
      </button>
      <button className="act act-msg"     onClick={() => onAction("message")}>
        <span className="act-glyph">✉</span>
        <span className="act-lbl">MESSAGE</span>
        <span className="act-key">[M]</span>
      </button>
      <button className="act act-invite"  onClick={() => onAction("invite")}>
        <span className="act-glyph">◈</span>
        <span className="act-lbl">INVITE TO {wantsGame ? window.GAMES[wantsGame].title.split(" ")[0] : "GAME"}</span>
      </button>
      <button className="act act-connect" onClick={() => onAction("connect")}>
        <span className="act-glyph">●</span>
        <span className="act-lbl">CONNECT</span>
        <span className="act-key">[C]</span>
      </button>
      <button className="act act-report"  onClick={() => onAction("report")}>
        <span className="act-glyph">⚐</span>
        <span className="act-lbl">REPORT</span>
      </button>
    </div>
  );
}

function HelpStrip() {
  return (
    <div className="help-strip">
      <span>← / → browse</span>
      <span>space flip</span>
      <span>drag to pass/connect</span>
      <span>[X] pass · [S] save · [M] message · [C] connect · [U] undo</span>
    </div>
  );
}

function Toast({ text, kind }) {
  return (
    <div className={`toast toast-${kind}`}>
      <span className="toast-mark">▸</span>
      <span>{text}</span>
    </div>
  );
}

function TweaksPanel({ tweaks, setTweaks }) {
  return (
    <div className="tweaks-panel">
      <div className="tweaks-title">TWEAKS</div>
      <div className="tweak-row">
        <label>Vibe representation</label>
        <div className="tweak-segmented">
          {["sliders","tags","prose","radar"].map(v => (
            <button key={v} className={tweaks.vibeMode === v ? "on" : ""} onClick={() => setTweaks({ vibeMode: v })}>{v}</button>
          ))}
        </div>
      </div>
      <div className="tweak-row">
        <label>Info density</label>
        <div className="tweak-segmented">
          {["sparse","ruled"].map(v => (
            <button key={v} className={tweaks.density === v ? "on" : ""} onClick={() => setTweaks({ density: v })}>{v}</button>
          ))}
        </div>
      </div>
      <div className="tweak-row">
        <label>Accent color</label>
        <div className="swatch-row">
          {[
            { hex: "#B13A2B", name: "ink red" },
            { hex: "#2B5E8A", name: "library blue" },
            { hex: "#6E5418", name: "mustard" },
            { hex: "#2F5E3E", name: "moss" },
            { hex: "#4A2C5C", name: "plum" },
            { hex: "#1A1714", name: "pure ink" },
          ].map(s => (
            <button
              key={s.hex}
              className={`swatch ${tweaks.accent === s.hex ? "on" : ""}`}
              style={{ background: s.hex }}
              onClick={() => setTweaks({ accent: s.hex })}
              title={s.name}
            />
          ))}
        </div>
      </div>
      <div className="tweak-row">
        <label>Card tilt</label>
        <input type="range" min="0" max="4" step="0.2" value={tweaks.cardRotation}
          onChange={e => setTweaks({ cardRotation: parseFloat(e.target.value) })}/>
        <span className="tweak-val">{tweaks.cardRotation.toFixed(1)}°</span>
      </div>
    </div>
  );
}

window.App = App;
