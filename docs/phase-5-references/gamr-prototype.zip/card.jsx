// Main ProfileCard component + Browser app with keyboard nav, swipe, flip, filter, undo.

const { useCallback, useEffect: useEffect2, useMemo: useMemo2, useRef: useRef2, useState: useState2 } = React;

function GamrLogo() {
  return (
    <div className="gamr-logo">
      <span className="gamr-stamp">●</span>
      <span className="gamr-word">gamr</span>
      <span className="gamr-sub">/ est. 2026 / platonic only</span>
    </div>
  );
}

// Rubber-stamp circle (top right of card)
function Stamp({ text, rotate = -12 }) {
  return (
    <div className="stamp" style={{ transform: `rotate(${rotate}deg)` }}>
      <div className="stamp-inner">
        <span className="stamp-text">{text}</span>
      </div>
    </div>
  );
}

// Hole-punched card edge
function PunchHoles() {
  return (
    <div className="punch-holes">
      {[0,1,2].map(i => <div key={i} className="punch-hole"/>)}
    </div>
  );
}

function ProfileCard({ profile, vibeMode, density, flipped, onFlip, accent }) {
  const g = profile;
  const ruled = density !== "sparse";

  return (
    <div className={`card-wrap ${flipped ? "flipped" : ""}`}>
      <div className="card-face card-front">
        <PunchHoles />
        <div className="card-inner">
          {/* Header row */}
          <div className="card-header">
            <div className="card-meta">
              <div className="card-id">GAMR / NO. {profile.id}</div>
              <div className="card-seen">SEEN {profile.seen.toUpperCase()} · JOINED {profile.joined.toUpperCase()}</div>
            </div>
            <Stamp text={profile.stamp} />
          </div>

          {/* Name block */}
          <div className="name-block">
            <div className="name-row">
              <h1 className="name">{profile.name}</h1>
              <span className="pronouns">[{profile.pronouns}]</span>
              <span className="age">· {profile.age}</span>
            </div>
            <div className="handle">@{profile.handle}</div>
          </div>

          {/* Looking-for stripe */}
          <div className="lft-stripe">
            <span className="lft-label">LOOKING&nbsp;FOR</span>
            <span className="lft-value">{profile.lft}</span>
          </div>

          {/* Two-column body */}
          <div className="card-body">
            {/* LEFT: games */}
            <section className="col col-games">
              <div className="col-heading">
                <span className="h-num">01</span>
                <span className="h-label">CURRENTLY PLAYING</span>
              </div>
              <div className="boxart-row">
                {profile.games.slice(0,3).map(code => (
                  <Boxart key={code} code={code} size="md"/>
                ))}
              </div>
              <div className="wants-row">
                <span className="wants-label">WANTS&nbsp;TO&nbsp;PLAY&nbsp;→</span>
                {profile.wants.map(code => (
                  <span key={code} className="wants-chip">
                    {window.GAMES[code].title}
                  </span>
                ))}
              </div>
            </section>

            {/* RIGHT: info stack */}
            <section className="col col-info">
              <div className="col-heading">
                <span className="h-num">02</span>
                <span className="h-label">LOGISTICS</span>
              </div>
              <dl className="logistics">
                <div className="log-row"><dt>TZ</dt><dd>{profile.tz}</dd></div>
                <div className="log-row"><dt>ONLINE</dt><dd>{profile.window}</dd></div>
                <div className="log-row"><dt>WEEKEND</dt><dd>{profile.weekend}</dd></div>
                <div className="log-row"><dt>HRS / WK</dt><dd>~{profile.hoursPerWeek}</dd></div>
                <div className="log-row"><dt>MIC</dt><dd>{profile.mic}</dd></div>
                <div className="log-row"><dt>PLATFORM</dt><dd className="platforms">{profile.platforms.map(p => <PlatformChip key={p} name={p}/>)}</dd></div>
              </dl>

              <div className="col-heading col-heading-2">
                <span className="h-num">03</span>
                <span className="h-label">VIBE</span>
              </div>
              <div className="vibe-box">
                {vibeMode === "sliders" && <VibeSliders vibe={profile.vibe}/>}
                {vibeMode === "tags" && <VibeTags vibe={profile.vibe} tags={profile.vibeTags}/>}
                {vibeMode === "prose" && <VibeProse prose={profile.vibeProse}/>}
                {vibeMode === "radar" && <VibeRadar vibe={profile.vibe}/>}
              </div>
            </section>
          </div>

          {/* Bio block */}
          <div className="bio-block">
            <div className="col-heading">
              <span className="h-num">04</span>
              <span className="h-label">ONE-LINER</span>
            </div>
            <p className="bio">{profile.bio}</p>
          </div>

          {/* Footer: location + flip */}
          <div className="card-footer">
            <div className="loc">◉ {profile.location}</div>
            <button className="flip-btn" onClick={onFlip}>
              FLIP CARD &rarr;
            </button>
          </div>

          {/* Ruled lines background */}
          {ruled && <div className="ruled-lines" aria-hidden="true"/>}
          <div className="redline" aria-hidden="true"/>
        </div>
      </div>

      {/* BACK of card */}
      <div className="card-face card-back">
        <PunchHoles />
        <div className="card-inner card-back-inner">
          <div className="card-header">
            <div className="card-meta">
              <div className="card-id">GAMR / NO. {profile.id} / VERSO</div>
              <div className="card-seen">ADDITIONAL NOTES</div>
            </div>
            <button className="flip-btn flip-btn-back" onClick={onFlip}>&larr; FLIP BACK</button>
          </div>

          <div className="back-body">
            <section className="back-section">
              <div className="col-heading"><span className="h-num">A</span><span className="h-label">FULL GAME LIST</span></div>
              <div className="back-games">
                {profile.games.map(code => (
                  <div key={code} className="back-game">
                    <Boxart code={code} size="sm"/>
                    <div className="back-game-meta">
                      <div className="back-game-title">{window.GAMES[code].title}</div>
                      <div className="back-game-genre">{window.GAMES[code].genre}</div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section className="back-section">
              <div className="col-heading"><span className="h-num">B</span><span className="h-label">REFERENCES</span></div>
              <ul className="references">
                <li>
                  <span className="ref-handle">@sunday.service</span> —
                  <span className="ref-quote">"showed up on time for 6 weeks. reliable."</span>
                </li>
                <li>
                  <span className="ref-handle">@dm_theodora</span> —
                  <span className="ref-quote">"rolled with the plot twist. good roleplayer."</span>
                </li>
                <li>
                  <span className="ref-handle">@rook_to_e4</span> —
                  <span className="ref-quote">"lost gracefully. would play again."</span>
                </li>
              </ul>
            </section>

            <section className="back-section">
              <div className="col-heading"><span className="h-num">C</span><span className="h-label">HARD NOS</span></div>
              <div className="hard-nos">
                <span className="no-chip">NO SLURS</span>
                <span className="no-chip">NO RAGE QUITS</span>
                <span className="no-chip">NO UNSOLICITED COACHING</span>
              </div>
            </section>

            <div className="back-footer">
              <div className="sig-line">
                <span className="sig-label">SIGNATURE / DATE</span>
                <span className="sig-scribble" style={{ fontFamily: "Caveat, cursive" }}>{profile.handle} · {profile.joined}</span>
              </div>
            </div>
          </div>
          <div className="redline" aria-hidden="true"/>
        </div>
      </div>
    </div>
  );
}

window.ProfileCard = ProfileCard;
